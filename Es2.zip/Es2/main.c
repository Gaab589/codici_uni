#include <stdio.h>
#include <math.h>

int stampaMenu();
float inserisciCoeff();
float inserisciCoeffNonNullo();
void calcolaEStampaRadici(float a, float b, float c);
void risolviMultiCompleta();

int main()
{
    int scelta;
    float a, b, c;
    do
    {
        scelta = stampaMenu();
        printf("\n");

        switch (scelta)
        {

        case 1:
            printf("1. Equazione Completa\n");

            printf("Inserisci il coefficiente 'a'\n");
            a = inserisciCoeffNonNullo();
            printf("Inserisci il coefficiente 'b'\n");
            b = inserisciCoeffNonNullo();
            printf("Inserisci il coefficiente 'c'\n");
            c = inserisciCoeffNonNullo();
            calcolaEStampaRadici(a, b, c);
            break;

        case 2:
            printf("2. Equazione Pura (b = 0)\n");

            printf("Inserisci il coefficiente 'a'\n");
            a = inserisciCoeffNonNullo();
            b = 0;
            printf("Inserisci il coefficiente 'c'\n");
            c = inserisciCoeffNonNullo();
            calcolaEStampaRadici(a, b, c);
            break;

        case 3:
            printf("3. Equazione Spuria (c = 0)\n");

            printf("Inserisci il coefficiente 'a'\n");
            a = inserisciCoeffNonNullo();
            printf("Inserisci il coefficiente 'b'\n");
            b = inserisciCoeffNonNullo();
            c = 0;
            calcolaEStampaRadici(a, b, c);
            break;

        case 4:
            printf("4. Risolvi n Equazioni Complete\n");

            risolviMultiCompleta();
            break;

        case 5:
            printf("Il programma si ssta chiudendo...\n");
            break;

        default:

            printf("ERRORE: Scelta non valida. Scegli un numero da 1 a 5.\n");
            break;
        }

        printf("\n");

    } while (scelta != 5);

    return 0;
}

int stampaMenu()
{
    int scelta;
    printf("======= MENU PRINCIPALE =======\n");
    printf("1. Risolvi equazione completa\n");
    printf("2. Risolvi equazione pura\n");
    printf("3. Risolvi equazione spuria\n");
    printf("4. Risolvi piu equazioni complete\n");
    printf("5. Esci\n");
    printf("Scegli un'opzione: ");
    scanf("%d", &scelta);
    return scelta;
}

float inserisciCoeff()
{
    float valore;
    scanf("%f", &valore);
    return valore;
}

float inserisciCoeffNonNullo()
{
    float valore;
    do
    {
        scanf("%f", &valore);
        if (valore == 0)
        {
            printf("ERRORE: Il coefficiente non puo' essere zero. Riprova.\n");
        }
    } while (valore == 0);
    return valore;
}

void risolviMultiCompleta()
{
    int n, i;
    float a, b, c;

    printf("Quante equazioni vuoi risolvere? ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("Numero non valido.\n");
        return;
    }

    for (i = 1; i <= n; i++)
    {
        printf("\nEquazione %d di %d\n", i, n);

        printf("Inserisci il coefficiente 'a'\n");
        a = inserisciCoeffNonNullo();
        printf("Inserisci il coefficiente 'b' (puoi anche inserire 0 adesso)\n");
        b = inserisciCoeff();
        printf("Inserisci il coefficiente 'c' (puoi anche inserire 0 adesso)\n");
        c = inserisciCoeff();

        calcolaEStampaRadici(a, b, c);
    }
}

void calcolaEStampaRadici(float a, float b, float c)
{
    float delta, x1, x2;

    printf("\nEquazione: %.2fx^2 + %.2fx + %.2f = 0\n", a, b, c);

    delta = (b * b) - (4 * a * c);
    printf("RISULTATO (Delta = %.2f):\n", delta);

    if (delta > 0)
    {
        printf("Delta > 0: Due radici reali e distinte.\n");

        x1 = (-b + sqrt(delta)) / (2 * a);
        x2 = (-b - sqrt(delta)) / (2 * a);
        printf("   X1 = %.2f\n", x1);
        printf("   X2 = %.2f\n", x2);
    }
    else if (delta == 0)
    {
        printf("Delta = 0: Una radice reale doppia.\n");
        x1 = -b / (2 * a);
        printf("   X1 = X2 = %.2f\n", x1);
    }
    else
    {
        printf("Delta < 0: Due radici complesse coniugate.\n");
        printf("OPZIONE NON IMPLEMENTATA\n");
    }
}